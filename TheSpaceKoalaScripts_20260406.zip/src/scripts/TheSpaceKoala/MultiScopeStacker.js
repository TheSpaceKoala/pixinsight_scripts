////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
//        _____ _                                                         //
//       |_   _| |__   ___                                                //
//         | | | '_ \ / _ \                                               //
//         | | | | | |  __/                                               //
//         |_| |_| |_|\___|          _  __           _                    //
//       / ___| _ __   __ _  ___ ___| |/ /___   __ _| | __ _              //
//       \___ \| '_ \ / _` |/ __/ _ \ ' // _ \ / _` | |/ _` |             //
//        ___) | |_) | (_| | (_|  __/ . \ (_) | (_| | | (_| |             //
//       |____/| .__/ \__,_|\___\___|_|\_\___/ \__,_|_|\__,_|             //
//             |_|                                                        //
////////////////////////////////////////////////////////////////////////////
// Multi Scope Stacker
// Version: V0.1.0 - 20260326
// Author: Luca Bartek, Roberto Sartori
// Website: www.thespacekoala.com
//
// This script should be used via the WeightedBatchPreProcessing script of PixInsight.
// It cannot be run standalone.
//
// This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
// To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/4.0/
//
// You are free to:
// 1. Share — copy and redistribute the material in any medium or format
// 2. Adapt — remix, transform, and build upon the material
//
// Under the following terms:
// 1. Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
// 2. NonCommercial — You may not use the material for commercial purposes.
//
// @license CC BY-NC 4.0 (http://creativecommons.org/licenses/by-nc/4.0/)
//
// COPYRIGHT © 2025 Luca Bartek, Roberto Sartori. ALL RIGHTS RESERVED.
////////////////////////////////////////////////////////////////////////////

///////////////////////////////////
//      PIPELINE BUILDER SCRIPT
///////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////
// PATCH WBPP TARGET FRAME GENERATION TO PRESERVE EXISTING DRIZZLE SIDE CARS
///////////////////////////////////////////////////////////////////////////////////

if (
  typeof WBPPUtils != 'undefined' &&
  typeof WBPPUtils.enableTargetFrames == 'function' &&
  !WBPPUtils.__tskEnableTargetFramesPatched__
) {
  WBPPUtils.__tskEnableTargetFramesPatched__ = true;
  WBPPUtils.__tskOriginalEnableTargetFrames__ = WBPPUtils.enableTargetFrames;

  WBPPUtils.enableTargetFrames = function (
    array,
    nColumns,
    enableDrizzle,
    enableLN
  ) {
    let target = new Array();
    for (let i = 0; i < array.length; ++i) {
      target[i] = new Array(nColumns);
      for (let j = 0; j < nColumns - 1; ++j) target[i][j] = true;

      if (typeof array[i] == 'string') {
        target[i][nColumns - 1] = array[i];
        if (enableDrizzle)
          target[i][nColumns] = File.changeExtension(array[i], '.xdrz');
        if (enableLN)
          target[i][nColumns + 1] = File.changeExtension(array[i], '.xnml');
      } else {
        target[i][nColumns - 1] = array[i].current;
        if (enableDrizzle)
          target[i][nColumns] =
            array[i].drizzleFile != undefined &&
            array[i].drizzleFile.length > 0
              ? array[i].drizzleFile
              : File.changeExtension(array[i].current, '.xdrz');
        if (enableLN) {
          if (array[i].localNormalizationFile != undefined)
            target[i][nColumns + 1] = array[i].localNormalizationFile;
          else target[i][nColumns + 1] = File.changeExtension(array[i].current, '.xnml');
        }
      }
    }
    return target;
  };
}

///////////////////////////////////////////////////////////////////////////////////
// MULTI-SCOPE POST GROUP REGROUPING
///////////////////////////////////////////////////////////////////////////////////

StackEngine.prototype.multiScopePostGroupKey = function (group) {
  let keywordPairs = [];

  if (group.keywords != undefined) {
    for (let keyword in group.keywords) {
      if (group.keywords.hasOwnProperty(keyword)) {
        keywordPairs.push(
          keyword.toLowerCase() +
            '=' +
            (group.keywords[keyword] == undefined
              ? ''
              : group.keywords[keyword].toString())
        );
      }
    }
  }

  keywordPairs.sort();

  return (
    'imageType=' +
    group.imageType +
    '|filter=' +
    group.filter +
    '|binning=' +
    group.binning +
    '|exposure=' +
    group.exposureTime +
    '|isCFA=' +
    group.isCFA +
    '|rgb=' +
    group.associatedRGBchannel +
    '|post=' +
    (keywordPairs.length > 0 ? keywordPairs.join('|') : 'none')
  );
};

StackEngine.prototype.removeGroupFromGroupsManager = function (groupToRemove) {
  let allGroups = this.groupsManager.groups;

  for (let i = allGroups.length - 1; i >= 0; --i) {
    if (allGroups[i] === groupToRemove) {
      this.groupsManager.removeGroupAtIndex(i);
      return true;
    }
  }

  return false;
};

StackEngine.prototype.mergeMultiScopePostGroup = function (
  keeperGroup,
  donorGroup
) {
  let donorItems = [];

  for (let j = 0; j < donorGroup.fileItems.length; ++j) {
    donorItems.push(donorGroup.fileItems[j]);
  }

  for (let j = 0; j < donorItems.length; ++j) {
    keeperGroup.fileItems.push(donorItems[j]);

    if (donorItems[j] != undefined && donorItems[j].exposureTime != undefined) {
      keeperGroup.addExposureTime(donorItems[j].exposureTime);
    }
  }

  if (
    engine.autoIntegrationMode &&
    keeperGroup.mode == WBPPGroupingMode.POST &&
    keeperGroup.imageType == ImageType.LIGHT &&
    keeperGroup.fileItems.length >= DEFAULT_AUTO_FAST_INTEGRATION_THRESHOLD &&
    keeperGroup.fastIntegrationData.manuallyChanged == false
  ) {
    keeperGroup.enableFastIntegration(true, true);
    if (engine.automaticFIgroups.indexOf(keeperGroup) < 0) {
      engine.automaticFIgroups.push(keeperGroup);
    }
  }
};

StackEngine.prototype.regroupPostGroupsForMultiScope = function (groups) {
  let regroupedGroups = [];
  let keeperByKey = {};
  let groupsToRemove = [];

  for (let i = 0; i < groups.length; ++i) {
    let group = groups[i];
    let eligibleForRegrouping =
      group.isActive &&
      group.imageType == ImageType.LIGHT &&
      group.associatedRGBchannel != WBPPAssociatedChannel.COMBINED_RGB;

    if (!eligibleForRegrouping) {
      regroupedGroups.push(group);
      continue;
    }

    // Keep the usual post-group identity, but ignore frame size so resolution-only splits collapse.
    let regroupingKey = this.multiScopePostGroupKey(group);

    if (!keeperByKey.hasOwnProperty(regroupingKey)) {
      keeperByKey[regroupingKey] = group;
      regroupedGroups.push(group);
      continue;
    }

    let keeperGroup = keeperByKey[regroupingKey];
    this.mergeMultiScopePostGroup(keeperGroup, group);
    group.isActive = false;
    group.__purged__ = true;
    groupsToRemove.push(group);

    console.noteln(
      "MultiScopeStacker regrouped POST group '" +
        group.folderName() +
        "' into '" +
        keeperGroup.folderName() +
        "' using key [" +
        regroupingKey +
        ']'
    );
  }

  for (let i = 0; i < groupsToRemove.length; ++i) {
    this.removeGroupFromGroupsManager(groupsToRemove[i]);
  }

  this.removePurgedElements();

  return this.groupsManager
    .groupsForMode(WBPPGroupingMode.POST)
    .filter(g => g.isActive);
};

//////////////////////////////////
//  PIPELINE BUILDER INSTRUCTIONS
///////////////////////////////////

let build = () => {

  // pre-process groups first
  let groupsPRE = engine.groupsManager.groupsForMode(WBPPGroupingMode.PRE);

  // CALIBRATION
  for (let i = 0; i < groupsPRE.length; ++i) {
    if (groupsPRE[i].imageType == ImageType.LIGHT) {
      let logEnv = {
        processLogger: engine.processLogger,
        group: groupsPRE[i],
      };

      // log header
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.newLine();
        env.params.processLogger.addMessage(
          env.params.group.logStringHeader('LIGHT FRAMES CALIBRATION')
        );
      }, logEnv);

      // calibration step (only if calibration masters are found)
      let cg = engine.getCalibrationGroupsFor(groupsPRE[i]);
      if (cg.masterBias || cg.masterDark || cg.masterFlat) {
        let calibrationOperation = new engine.calibrationOperation(
          groupsPRE[i]
        );
        engine.WS.calibrationLight.size += calibrationOperation.spaceRequired();
        engine.operationQueue.addOperation(calibrationOperation);
      }

      // log footer
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.addMessage(env.params.group.logStringFooter());
        env.params.processLogger.newLine();
      }, logEnv);
    }
  }

  var groupsToCalibrate = groupsPRE.slice();
  for (var j = groupsToCalibrate.length - 1; j >= 0; j--) {
    var cg = engine.getCalibrationGroupsFor(groupsToCalibrate[j]);

    // Check if none of the conditions are true
    if (!(cg.masterBias || cg.masterDark || cg.masterFlat)) {
      // Remove the group from the list if the condition is met
      groupsToCalibrate.splice(j, 1);
    }
  }
  for (let i = 0; i < groupsPRE.length; ++i) {
    // LINEAR PATTERN SUBTRACTION
    if (engine.linearPatternSubtraction) {
      let logEnv = {
        processLogger: engine.processLogger,
      };
      // log header
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.newLine();
        env.params.processLogger.addMessage(
          '<b>********************</b> <i>LINEAR DEFECTS CORRECTION</i> <b>********************</b>'
        );
      }, logEnv);

      let LPSOperation = new engine.LPSOperation();
      engine.WS.LPS.size += LPSOperation.spaceRequired();
      engine.operationQueue.addOperation(LPSOperation);

      // log footer
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.addMessage('<b>' + SEPARATOR + '</b>');
        env.params.processLogger.newLine();
      }, logEnv);
    }
  }
  // COSMETIC CORRECTON AND DEBAYER

  for (let i = 0; i < groupsPRE.length; ++i) {
    if (groupsPRE[i].imageType == ImageType.LIGHT) {
      let logEnv = {
        processLogger: engine.processLogger,
        group: groupsPRE[i],
      };

      let needsCC =
        groupsPRE[i].ccData.CCTemplate &&
        groupsPRE[i].ccData.CCTemplate.length > 0;
      let needsDebayer = groupsPRE[i].isCFA;

      if (!needsCC && !needsDebayer) continue;

      // log header
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.newLine();
        env.params.processLogger.addMessage(
          env.params.group.logStringHeader(
            (needsCC ? 'COSMETIZATION' : '') +
              (needsCC && needsDebayer ? ' and ' : '') +
              (needsDebayer ? 'DEBAYERING' : '')
          )
        );
      }, logEnv);

      // cosmetic correction
      if (needsCC) {
        let cosmeticCorretcionOperation =
          new engine.CosmeticCorrectionOperation(groupsPRE[i]);
        engine.WS.cosmeticCorrection.size +=
          cosmeticCorretcionOperation.spaceRequired();
        engine.operationQueue.addOperation(cosmeticCorretcionOperation);
      }

      // debayer
      if (needsDebayer) {
        let debayerOperation = new engine.DebayerOperation(groupsPRE[i]);
        engine.WS.debayer.size += debayerOperation.spaceRequired();
        engine.operationQueue.addOperation(debayerOperation);
      }

      // log footer
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.addMessage(env.params.group.logStringFooter());
        env.params.processLogger.newLine();
      }, logEnv);
    }
  }
  // POST-PROCESS GROUPS
  let groupsPOST = engine.regroupPostGroupsForMultiScope(
    engine.groupsManager.groupsForMode(WBPPGroupingMode.POST)
  );

  // REFERENCE FRAME DATA PREPARATION
  if (!engine.reuseLastReferenceFrames)
    engine.operationQueue.addOperation(
      new engine.ReferenceFrameDataPreparationOperation()
    );

  // MEASUREMENT OPERATION
  let generateSubframesWeights =
    engine.subframeWeightingEnabled &&
    (engine.subframesWeightsMethod == WBPPSubframeWeightsMethod.FORMULA ||
      engine.integrate);
  let frameSelectionEnabled =
    typeof engine.FrameSelectionOperation === 'function' &&
    typeof engine.frameSelectionEnabled != 'undefined' &&
    engine.frameSelectionEnabled;
  let measureForBestFrameSelection =
    (engine.imageRegistration || engine.fastMode) &&
    engine.bestFrameReferenceMethod != WBPPBestReferenceMethod.MANUAL &&
    !engine.reuseLastReferenceFrames;
  let measureForFrameSelection = frameSelectionEnabled;
  let measureImages =
    generateSubframesWeights ||
    measureForBestFrameSelection ||
    engine.localNormalization ||
    measureForFrameSelection;
  if (!engine.groupsManager.isEmpty() && measureImages) {
    engine.operationQueue.addOperation(new engine.MeasurementOperation());
    if (
      engine.subframeWeightingEnabled &&
      engine.subframesWeightsMethod == WBPPSubframeWeightsMethod.FORMULA
    )
      engine.operationQueue.addOperation(
        new engine.CustomFormulaWeightsGenerationOperation()
      );
    if (frameSelectionEnabled) {
      engine.operationQueue.addOperation(new engine.FrameSelectionOperation());
    }
    if (
      engine.subframesWeightsMethod != WBPPSubframeWeightsMethod.PSFScaleSNR &&
      engine.integrate &&
      engine.groupsManager.regularIntegrationGroupExists()
    )
      engine.operationQueue.addOperation(
        new engine.BadFramesRejectionOperation()
      );
  }

  // SET THE REFERENCE FRAME (for both post calibration group with or without fast integration )
  let regularRegistrationGroupExists =
    engine.imageRegistration &&
    engine.groupsManager.regularIntegrationGroupExists();
  if (
    !engine.groupsManager.isEmpty() &&
    (regularRegistrationGroupExists ||
      (engine.groupsManager.fastIntegrationGroupExists() && engine.integrate))
  )
    if (!engine.reuseLastReferenceFrames)
      engine.operationQueue.addOperation(
        new engine.ReferenceFrameSelectionOperation()
      );

  // exit if no registration, local normalization and integration needs to be performed
  if (
    !generateSubframesWeights &&
    !engine.imageRegistration &&
    !engine.localNormalization &&
    !engine.integrate
  )
    return;

  // POST-PROCESS GROUPS - REGISTRATION
  if (engine.imageRegistration) {
    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
          WBPPAssociatedChannel.COMBINED_RGB &&
        !groupsPOST[i].fastIntegrationData.enabled;

      if (standardPostCalibrationProcessing) {
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('IMAGE REGISTRATION')
          );
        }, logEnv);

        let registrationOperation = new engine.RegistrationOperation(
          groupsPOST[i]
        );
        engine.WS.registration.size += registrationOperation.spaceRequired();
        engine.operationQueue.addOperation(registrationOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }
  }

  // POST-PROCESS GROUPS - LOCAL NORMALIZATION REFERENCE FRAME SELECTION
  if (engine.localNormalization)
    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
          WBPPAssociatedChannel.COMBINED_RGB &&
        !groupsPOST[i].fastIntegrationData.enabled;

      if (standardPostCalibrationProcessing) {
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader(
              'LOCAL NORMALIZATION - REFERENCE FRAME SELECTION'
            )
          );
        }, logEnv);

        if (!engine.reuseLastLNReferenceFrames) {
          let lnReferenceFrameSelectionOperation =
            new engine.LocalNormalizationReferenceFrameSelectionOperation(
              groupsPOST[i]
            );
          engine.WS.localNormalization.size +=
            lnReferenceFrameSelectionOperation.spaceRequired();
          engine.operationQueue.addOperation(
            lnReferenceFrameSelectionOperation
          );
        }

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

  // POST-PROCESS GROUPS - LOCAL NORMALIZATION
  if (engine.localNormalization)
    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
          WBPPAssociatedChannel.COMBINED_RGB &&
        !groupsPOST[i].fastIntegrationData.enabled;

      if (standardPostCalibrationProcessing) {
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('LOCAL NORMALIZATION')
          );
        }, logEnv);

        let lnOperation = new engine.LocalNormalizationOperation(groupsPOST[i]);
        engine.WS.localNormalization.size += lnOperation.spaceRequired();
        engine.operationQueue.addOperation(lnOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

  // POST-PROCESS GROUPS - IMAGE INTGEGRATION

  if (engine.integrate) {
    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
        WBPPAssociatedChannel.COMBINED_RGB;

      if (
        standardPostCalibrationProcessing &&
        !groupsPOST[i].fastIntegrationData.enabled
      ) {
        // Image Integration
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('IMAGE INTEGRATION')
          );
        }, logEnv);

        let imageIntegrationOperation = new engine.ImageIntegrationOperation(
          groupsPOST[i]
        );
        engine.WS.integration.size += imageIntegrationOperation.spaceRequired();
        engine.operationQueue.addOperation(imageIntegrationOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

    // FAST INTEGRATION

    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
        WBPPAssociatedChannel.COMBINED_RGB;

      if (
        standardPostCalibrationProcessing &&
        groupsPOST[i].fastIntegrationData.enabled
      ) {
        // Fast Integration
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('FAST INTEGRATION')
          );
        }, logEnv);

        let fastIntegrationOperation = new engine.FastIntegrationOperation(
          groupsPOST[i]
        );
        engine.WS.fastIntegration.size +=
          fastIntegrationOperation.spaceRequired();
        let imageIntegrationOperation = new engine.ImageIntegrationOperation(
          groupsPOST[i]
        );
        engine.WS.integration.size += imageIntegrationOperation.spaceRequired();
        engine.operationQueue.addOperation(fastIntegrationOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

    // DRIZZLE INTEGRATION

    for (let i = 0; i < groupsPOST.length; ++i) {
      let standardPostCalibrationProcessing =
        groupsPOST[i].associatedRGBchannel !=
        WBPPAssociatedChannel.COMBINED_RGB;

      if (
        standardPostCalibrationProcessing &&
        groupsPOST[i].isDrizzleEnabled()
      ) {
        // Fast Integration
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('DRIZZLE INTEGRATION')
          );
        }, logEnv);

        let drizzleIntegrationOperation =
          new engine.DrizzleIntegrationOperation(groupsPOST[i]);
        engine.WS.integration.size +=
          drizzleIntegrationOperation.spaceRequired();
        engine.operationQueue.addOperation(drizzleIntegrationOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

    // AUTO CROP

    if (engine.integrate && engine.autocrop && groupsPOST.length > 0) {
      let logEnv = {
        processLogger: engine.processLogger,
      };

      // log header
      engine.operationQueue.addOperationBlock(env => {
        console.writeln();
        env.params.processLogger.addMessage(
          '<b>*********************** <i>AUTO CROP</i> ***********************</b>'
        );
        console.writeln(SEPARATOR);
        console.writeln('* Begin autocrop of master light frames');
        console.writeln(SEPARATOR);
      }, logEnv);

      let autocropOperation = new engine.AutoCropOperation();
      engine.WS.integration.size += autocropOperation.spaceRequired();
      engine.operationQueue.addOperation(autocropOperation);

      // log footer
      engine.operationQueue.addOperationBlock(env => {
        env.params.processLogger.addMessage('<b>' + SEPARATOR + '</b>');
        env.params.processLogger.newLine();
        console.writeln(SEPARATOR);
        console.writeln('* End autocrop of master light frames');
        console.writeln(SEPARATOR);
      }, logEnv);
    }

    // process the RGB recombination groups, this needs to be done at the end to ensure that all
    // gray R,G and B masters have been integrated
    for (let i = 0; i < groupsPOST.length; ++i) {
      let logEnv = {
        processLogger: engine.processLogger,
        group: groupsPOST[i],
      };

      // RGB RECOMBINATION
      if (
        groupsPOST[i].associatedRGBchannel == WBPPAssociatedChannel.COMBINED_RGB
      ) {
        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('RGB COMBINATION')
          );
        }, logEnv);

        // RGB Recombination
        let recombinationOperation = new engine.RGBRecombinationOperation(
          groupsPOST[i]
        );
        engine.WS.recombination.size += recombinationOperation.spaceRequired();
        engine.operationQueue.addOperation(recombinationOperation);

        // log footer
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter()
          );
          env.params.processLogger.newLine();
        }, logEnv);
      }
    }

    // Plate solve
    if (engine.integrate && engine.platesolve) {
      for (let i = 0; i < groupsPOST.length; ++i) {
        // Image Integration
        let logEnv = {
          processLogger: engine.processLogger,
          group: groupsPOST[i],
        };

        // log header
        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringHeader('ASTROMETRIC SOLUTION')
          );
        }, logEnv);

        let plateSolveOperation = new engine.PlateSolveOperation(groupsPOST[i]);
        engine.operationQueue.addOperation(plateSolveOperation);

        engine.operationQueue.addOperationBlock(env => {
          env.params.processLogger.addMessage(
            env.params.group.logStringFooter('COMPLETED')
          );
        }, logEnv);
      }
    }

  }
};

build();
